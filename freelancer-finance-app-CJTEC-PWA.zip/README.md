
# Financeiro Freelancer — CJTEC (PWA + Testes + Deploy)

## Rodar
```bash
npm i
npm run dev
```

## Build + PWA
```bash
npm run build   # Vite build + gera service-worker com precache
npm run preview
```

## Testes
```bash
npm run test       # Vitest headless
npm run test:ui    # UI
npm run coverage
```

## Cypress E2E
Em um terminal: `npm run dev`  
Em outro: `npm run cy:open` (ou `npm run cy:run`)

## Deploy (Vercel)
1. Crie um repo no GitHub e faça push do projeto.
2. Vercel → Add New Project → importe o repo.
3. Build Command: `npm run build`
4. Output Directory: `dist`
5. Deploy. Abra no celular e **Adicionar à tela inicial**.

## Deploy (Netlify)
1. Conecte o repo ou arraste a pasta `dist/`.
2. Build: `npm run build`
3. Publish: `dist`

## PWA
- `public/manifest.json` + ícones CJTEC.
- `scripts/generate-sw.js` gera `dist/service-worker.js` com precache (Workbox-like).
- `index.html` com meta iOS e theme-color.
