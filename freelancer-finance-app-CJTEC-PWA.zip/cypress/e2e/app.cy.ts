
describe('Freelancer Finance App', () => {
  it('creates a new income transaction via modal', () => {
    cy.visit('/')
    cy.get('[data-testid="new-transaction"]').click()
    cy.get('[data-testid="field-desc"]').type('Landing Page')
    cy.get('[data-testid="field-client"]').type('Cliente X')
    cy.get('[data-testid="field-amount"]').type('1500')
    cy.get('[data-testid="btn-save"]').click()
    cy.get('[data-testid="table-transactions"]').contains('Landing Page')
  })
})
