
import { promises as fs } from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'

const dist = path.resolve('dist')
const out = path.resolve('dist', 'service-worker.js')

async function walk(dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true })
  const files = []
  for (const e of entries) {
    const fp = path.join(dir, e.name)
    if (e.isDirectory()) files.push(...await walk(fp))
    else files.push(fp)
  }
  return files
}

function webPath(fp) { return '/' + path.relative(dist, fp).replace(/\\/g,'/') }
function hash(buf) { return crypto.createHash('sha256').update(buf).digest('hex').slice(0,8) }

const SKIP = [/\.map$/i, /service-worker\.js$/i]

const files = (await walk(dist)).filter(f => !SKIP.some(re => re.test(f)))
const manifest = []
let concat = ''
for (const f of files) {
  const p = webPath(f)
  const buf = await fs.readFile(f)
  const h = hash(buf)
  manifest.push({ url: p, revision: h })
  concat += h
}
const VERSION = 'v' + hash(Buffer.from(concat))

const sw = `
/* Auto-generated precache SW */
const PRECACHE = ${JSON.stringify(manifest, null, 2)};
const CACHE = 'finfreela-${'${VERSION}'}';

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await cache.addAll(PRECACHE.map(e => e.url));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.map(k => k === CACHE ? null : caches.delete(k)));
    self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(req);
    if (cached) {
      fetch(req).then(res => cache.put(req, res.clone())).catch(()=>{});
      return cached;
    }
    try {
      const res = await fetch(req);
      cache.put(req, res.clone());
      return res;
    } catch (e) {
      if (req.mode === 'navigate') {
        const index = await cache.match('/index.html');
        if (index) return index;
      }
      throw e;
    }
  })());
});
`
await fs.writeFile(out, sw, 'utf8')
console.log('Generated', out)
