
import { describe, it, expect } from 'vitest'
import { BRL, parseBRNumber, calcProgressiveTax, monthSeries, netOfFees, DEFAULT_SETTINGS } from '../finance'

describe('finance helpers', () => {
  it('formats BRL', () => {
    const v = BRL(1234.56)
    expect(v.startsWith('R$')).toBe(true)
  })
  it('parses 1.234,56', () => {
    const n = parseBRNumber('1.234,56')
    expect(Math.abs(n - 1234.56)).toBeLessThan(1e-6)
  })
  it('net of fees 22%', () => {
    const n = netOfFees(1000, { platformPct:15, inssPct:5, issPct:2 })
    expect(Math.abs(n - 780)).toBeLessThan(1e-6)
  })
  it('progressive tax within expected window', () => {
    const tax = calcProgressiveTax(5000, DEFAULT_SETTINGS.irpfBrackets as any)
    expect(tax).toBeGreaterThan(450)
    expect(tax).toBeLessThan(550)
  })
  it('month series aggregates', () => {
    const ms = monthSeries([
      { type:'income', date:'2025-01-10', amount:1000 },
      { type:'expense', date:'2025-01-15', amount:200 },
      { type:'income', date:'2025-02-01', amount:500 },
    ] as any)
    const jan = ms.find(r=>r.month==='2025-01') as any
    const fev = ms.find(r=>r.month==='2025-02') as any
    expect(jan.income).toBe(1000)
    expect(jan.expense).toBe(200)
    expect(fev.income).toBe(500)
    expect(fev.expense).toBe(0)
  })
})
