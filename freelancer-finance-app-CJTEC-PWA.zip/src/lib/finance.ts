
export const BRL = (v:number) =>
  new Intl.NumberFormat('pt-BR',{style:'currency', currency:'BRL'}).format(Number(v||0))

export const parseBRNumber = (s:any) => {
  if (typeof s === 'number') return s
  if (!s) return 0
  const clean = String(s)
    .replace(/[^\d,\.\-]/g,'')
    .replace(/\.(?=.*\.)/g,'')
    .replace(/,(\d{2})$/, '.$1')
  const n = Number(clean)
  return isNaN(n)? 0 : n
}

export const monthKey = (date:string|Date) => {
  const d = new Date(date)
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`
}

export const startOfMonth = (date:Date) => new Date(date.getFullYear(), date.getMonth(), 1)
export const endOfMonth = (date:Date) => new Date(date.getFullYear(), date.getMonth()+1, 0)

export type Bracket = { label:string, limit?:number, rate:number }
export function calcProgressiveTax(base:number, brackets:Bracket[]) {
  let tax = 0, last = 0
  for (const b of brackets) {
    const limit = b.limit ?? Infinity
    const slice = Math.max(0, Math.min(base, limit) - last)
    if (slice>0) tax += slice * (b.rate/100)
    last = limit
    if (base <= limit) break
  }
  return Math.max(0, tax)
}

export function monthSeries(transactions:any[]) {
  const map = new Map()
  for (const t of transactions) {
    const key = monthKey(t.date)
    if (!map.has(key)) map.set(key, { month:key, income:0, expense:0 })
    const row:any = map.get(key)
    if (t.type==='income') row.income += t.amount
    else row.expense += t.amount
  }
  return Array.from(map.values()).sort((a:any,b:any)=>a.month.localeCompare(b.month))
}

export function netOfFees(amount:number, fees:{ platformPct?:number, inssPct?:number, issPct?:number, otherPct?:number }) {
  const totalPct = ((fees.platformPct||0)+(fees.inssPct||0)+(fees.issPct||0)+(fees.otherPct||0))/100
  return amount * (1 - totalPct)
}

export const DEFAULT_SETTINGS = {
  irpfBrackets: [
    { label:'Faixa 1', limit: 2259.20, rate: 0 },
    { label:'Faixa 2', limit: 2826.65, rate: 7.5 },
    { label:'Faixa 3', limit: 3751.05, rate: 15 },
    { label:'Faixa 4', limit: 4664.68, rate: 22.5 },
    { label:'Faixa 5', rate: 27.5 },
  ],
  defaultFees: { platformPct: 15, inssPct: 5, issPct: 2, otherPct: 0 }
}
