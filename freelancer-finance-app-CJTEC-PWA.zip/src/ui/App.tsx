
import React, { useMemo, useState } from 'react'
import { Layers3, Plus } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts'
import { Card, CardHeader, CardTitle, CardContent, Button, Input, Label, Dialog, DialogHeader, DialogTitle, DialogContent, DialogFooter, Tabs, TabsList, TabsTrigger, TabsContent, Switch } from './primitives'
import { BRL, parseBRNumber, startOfMonth, endOfMonth, monthSeries, netOfFees, calcProgressiveTax, DEFAULT_SETTINGS } from '../lib/finance'

type Tx = {
  id: string; type: 'income'|'expense'; date:string; description:string; client:string;
  category:string; platform:string; amount:number; taxable:boolean;
  fees: { platformPct:number, inssPct:number, issPct:number, otherPct:number }
}

const LS_KEY = 'freelance_finance_v1'

const seed: { transactions: Tx[], settings: any, invoices: any[] } = {
  transactions:[
    { id: crypto.randomUUID(), type:'income', date: new Date().toISOString().slice(0,10), description:'Site institucional (CJTEC)', client:'Cliente A', category:'Web', platform:'Direto', amount:3500, taxable:true, fees:{ platformPct:0, inssPct:5, issPct:2, otherPct:0 } },
    { id: crypto.randomUUID(), type:'expense', date: new Date().toISOString().slice(0,10), description:'Hospedagem HostGator (anual)', client:'Infra', category:'Infraestrutura', platform:'HostGator', amount:420, taxable:false, fees:{ platformPct:0, inssPct:0, issPct:0, otherPct:0 } }
  ],
  settings: DEFAULT_SETTINGS,
  invoices: []
}

function useStorage() {
  const [state, setState] = React.useState(()=>{
    try { const raw = localStorage.getItem(LS_KEY); return raw? JSON.parse(raw): seed } catch { return seed }
  })
  React.useEffect(()=>{ localStorage.setItem(LS_KEY, JSON.stringify(state)) }, [state])
  return [state, setState] as const
}

function useKPIs(transactions:Tx[]) {
  const now = new Date()
  const mStart = startOfMonth(now)
  const mEnd = endOfMonth(now)
  const { income, expense } = useMemo(()=>{
    let inc=0, exp=0
    for (const t of transactions) {
      const d = new Date(t.date)
      if (d>=mStart && d<=mEnd) {
        if (t.type==='income') inc += t.amount
        else exp += t.amount
      }
    }
    return { income:inc, expense:exp }
  }, [transactions])
  return { income, expense, balance: income-expense }
}

function TransactionForm({ open, onClose, onSubmit, initial }:{ open:boolean, onClose:()=>void, onSubmit:(t:Tx)=>void, initial?:Tx }) {
  const [type, setType] = useState(initial?.type || 'income')
  const [date, setDate] = useState(initial?.date || new Date().toISOString().slice(0,10))
  const [description, setDescription] = useState(initial?.description || '')
  const [client, setClient] = useState(initial?.client || '')
  const [category, setCategory] = useState(initial?.category || '')
  const [platform, setPlatform] = useState(initial?.platform || '')
  const [amount, setAmount] = useState(String(initial?.amount ?? ''))
  const [taxable, setTaxable] = useState(initial?.taxable ?? true)
  const [fees, setFees] = useState(initial?.fees || { platformPct:0, inssPct:0, issPct:0, otherPct:0 })

  return (
    <Dialog open={open}>
      <DialogHeader><DialogTitle>{initial? 'Editar lançamento' : 'Novo lançamento'}</DialogTitle></DialogHeader>
      <DialogContent>
        <div className="grid gap-3" data-testid="transaction-form">
          <div className="grid grid-cols-2 gap-2">
            <div><Label>Tipo</Label>
              <select data-testid="field-type" className="px-3 py-2 rounded-xl border w-full" value={type} onChange={(e)=>setType(e.target.value as any)}>
                <option value="income">Receita</option>
                <option value="expense">Despesa</option>
              </select>
            </div>
            <div><Label>Data</Label>
              <Input data-testid="field-date" type="date" value={date} onChange={e=>setDate(e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div><Label>Descrição</Label><Input data-testid="field-desc" value={description} onChange={e=>setDescription(e.target.value)} /></div>
            <div><Label>Cliente</Label><Input data-testid="field-client" value={client} onChange={e=>setClient(e.target.value)} /></div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div><Label>Categoria</Label><Input data-testid="field-category" value={category} onChange={e=>setCategory(e.target.value)} /></div>
            <div><Label>Plataforma</Label><Input data-testid="field-platform" value={platform} onChange={e=>setPlatform(e.target.value)} /></div>
            <div><Label>Valor</Label><Input data-testid="field-amount" value={amount} onChange={e=>setAmount(e.target.value)} /></div>
          </div>
          <div className="grid grid-cols-4 gap-2">
            <div><Label>Taxa plataforma %</Label><Input data-testid="field-platformPct" type="number" value={fees.platformPct} onChange={e=>setFees({...fees, platformPct:Number(e.target.value)})} /></div>
            <div><Label>INSS %</Label><Input data-testid="field-inssPct" type="number" value={fees.inssPct} onChange={e=>setFees({...fees, inssPct:Number(e.target.value)})} /></div>
            <div><Label>ISS %</Label><Input data-testid="field-issPct" type="number" value={fees.issPct} onChange={e=>setFees({...fees, issPct:Number(e.target.value)})} /></div>
            <div><Label>Outros %</Label><Input data-testid="field-otherPct" type="number" value={fees.otherPct} onChange={e=>setFees({...fees, otherPct:Number(e.target.value)})} /></div>
          </div>
          <div className="flex items-center gap-2">
            <Switch checked={taxable} onChange={setTaxable} /> <Label>Conta para IRPF</Label>
          </div>
          <DialogFooter>
            <Button data-testid="btn-cancel" onClick={onClose}>Cancelar</Button>
            <Button data-testid="btn-save" onClick={()=>{
              onSubmit({
                id: initial?.id || crypto.randomUUID(),
                type: type as any, date, description, client, category, platform,
                amount: Number((amount||'0').replace(/[^\d,\.\-]/g,'').replace(/,(\d{2})$/,'.$1')) || 0,
                taxable, fees: { ...fees }
              })
              onClose()
            }}>Salvar</Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default function App() {
  const [data, setData] = useStorage()
  const [tab, setTab] = useState('dashboard')
  const [modalOpen, setModalOpen] = useState(false)
  const [editing, setEditing] = useState<Tx|null>(null)

  const kpis = useKPIs(data.transactions)
  const series = useMemo(()=>monthSeries(data.transactions), [data.transactions])

  const addTx = (t:Tx)=> setData({ ...data, transactions:[t, ...data.transactions] })
  const updateTx = (t:Tx)=> setData({ ...data, transactions: data.transactions.map(x=>x.id===t.id? t : x) })
  const deleteTx = (id:string)=> setData({ ...data, transactions: data.transactions.filter(x=>x.id!==id) })

  const openCreate = ()=>{ setEditing(null); setModalOpen(true) }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <header className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl border flex items-center justify-center"><Layers3 /></div>
          <div>
            <h1 className="text-2xl font-semibold">Financeiro Freelancer — CJTEC</h1>
            <p className="text-sm text-gray-500">Controle receitas, despesas, impostos e faturas</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button data-testid="new-transaction" onClick={openCreate}><Plus className="w-4 h-4" /> Novo lançamento</Button>
        </div>
      </header>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger tab="dashboard" value={tab} onValueChange={setTab}>Dashboard</TabsTrigger>
          <TabsTrigger tab="transactions" value={tab} onValueChange={setTab}>Lançamentos</TabsTrigger>
          <TabsTrigger tab="tax" value={tab} onValueChange={setTab}>Planejador Fiscal</TabsTrigger>
        </TabsList>

        <TabsContent tab="dashboard" value={tab}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4">
            <Card><CardHeader><CardTitle>Receitas (mês)</CardTitle></CardHeader><CardContent data-testid="kpi-income">{BRL(kpis.income)}</CardContent></Card>
            <Card><CardHeader><CardTitle>Despesas (mês)</CardTitle></CardHeader><CardContent data-testid="kpi-expense">{BRL(kpis.expense)}</CardContent></Card>
            <Card><CardHeader><CardTitle>Saldo (mês)</CardTitle></CardHeader><CardContent data-testid="kpi-balance">{BRL(kpis.balance)}</CardContent></Card>
          </div>
          <Card className="mt-4">
            <CardHeader><CardTitle>Evolução mensal</CardTitle></CardHeader>
            <CardContent style={{height:320}}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={series}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="income" name="Receitas" />
                  <Line type="monotone" dataKey="expense" name="Despesas" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent tab="transactions" value={tab}>
          <div className="flex items-center justify-between mt-4">
            <h3 className="text-lg font-semibold">Lançamentos</h3>
            <Button data-testid="toolbar-new" onClick={openCreate}>Novo</Button>
          </div>
          <div className="overflow-auto rounded-2xl border mt-3">
            <table className="min-w-full text-sm" data-testid="table-transactions">
              <thead className="bg-gray-50">
                <tr><th className="p-2 text-left">Data</th><th className="p-2 text-left">Tipo</th><th className="p-2 text-left">Descrição</th><th className="p-2 text-right">Valor</th><th className="p-2 text-right">Ações</th></tr>
              </thead>
              <tbody>
                {data.transactions.map((t:Tx)=>(
                  <tr key={t.id} className="border-t">
                    <td className="p-2">{new Date(t.date).toLocaleDateString('pt-BR')}</td>
                    <td className="p-2">{t.type==='income'?'Receita':'Despesa'}</td>
                    <td className="p-2">{t.description}</td>
                    <td className="p-2 text-right">{BRL(t.amount)}</td>
                    <td className="p-2 text-right">
                      <div className="flex gap-2 justify-end">
                        <Button data-testid={`btn-edit-${t.id}`} onClick={()=>{ setEditing(t); setModalOpen(true)}}>Editar</Button>
                        <Button data-testid={`btn-del-${t.id}`} onClick={()=>deleteTx(t.id)}>Excluir</Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TabsContent>

        <TabsContent tab="tax" value={tab}>
          <Card className="mt-4">
            <CardHeader><CardTitle>Estimativa mensal (base x IRPF)</CardTitle></CardHeader>
            <CardContent style={{height:320}}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={
                  (()=>{
                    const map = new Map<string, number>()
                    for (const t of data.transactions) {
                      if (t.type==='income' && t.taxable) {
                        const key = t.date.slice(0,7)
                        map.set(key, (map.get(key)||0) + netOfFees(t.amount, t.fees))
                      }
                    }
                    return Array.from(map.entries()).map(([month, base])=>{
                      const tax = calcProgressiveTax(base, data.settings.irpfBrackets)
                      return { month, base, tax, net: base - tax }
                    })
                  })()
                }>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="base" name="Base" />
                  <Bar dataKey="tax" name="IRPF" />
                  <Bar dataKey="net" name="Líquido" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {modalOpen && (
        <TransactionForm
          open={modalOpen}
          onClose={()=>setModalOpen(false)}
          onSubmit={(t)=> editing? updateTx(t): addTx(t)}
          initial={editing||undefined}
        />
      )}
    </div>
  )
}

function useStorage() {
  const [state, setState] = React.useState(()=>{
    try { const raw = localStorage.getItem('freelance_finance_v1'); return raw? JSON.parse(raw) : { transactions: [], settings: DEFAULT_SETTINGS, invoices: [] } } catch { return { transactions: [], settings: DEFAULT_SETTINGS, invoices: [] } }
  })
  React.useEffect(()=>{ localStorage.setItem('freelance_finance_v1', JSON.stringify(state)) }, [state])
  return [state, setState] as const
}
