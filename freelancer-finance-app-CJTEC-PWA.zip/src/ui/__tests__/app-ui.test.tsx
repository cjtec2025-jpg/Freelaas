
import { describe, it, expect } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import React from 'react'
import App from '../App'

describe('App UI', () => {
  it('renders and opens new transaction modal', () => {
    render(<App />)
    expect(screen.getByText(/Financeiro Freelancer/i)).toBeInTheDocument()
    fireEvent.click(screen.getByTestId('new-transaction'))
    expect(screen.getByTestId('transaction-form')).toBeInTheDocument()
  })
})
