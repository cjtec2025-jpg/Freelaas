
import React from 'react'

export const Card = ({children, className}:{children:any, className?:string}) => (
  <div className={`rounded-2xl border shadow-sm ${className||''}`}>{children}</div>
)
export const CardHeader = ({children, className}:{children:any, className?:string}) => (
  <div className={`p-4 border-b ${className||''}`}>{children}</div>
)
export const CardTitle = ({children, className}:{children:any, className?:string}) => (
  <h3 className={`text-lg font-semibold ${className||''}`}>{children}</h3>
)
export const CardContent = ({children, className}:{children:any, className?:string}) => (
  <div className={`p-4 ${className||''}`}>{children}</div>
)
export const Button = ({children, onClick, type='button', 'data-testid':tid, className}:{children:any, onClick?:any, type?:any, 'data-testid'?:string, className?:string}) => (
  <button data-testid={tid} type={type} onClick={onClick} className={`px-3 py-2 rounded-xl border hover:opacity-90 ${className||''}`}>{children}</button>
)
export const Input = React.forwardRef<HTMLInputElement, any>(({className, ...props}, ref) => (
  <input ref={ref} className={`px-3 py-2 rounded-xl border w-full ${className||''}`} {...props} />
))
Input.displayName='Input'
export const Label = ({children}:{children:any}) => <label className="text-sm text-gray-600">{children}</label>

export const Dialog = ({open, children}:{open:boolean, children:any}) => open? <div className="fixed inset-0 bg-black/30 flex items-center justify-center"><div className="bg-white rounded-2xl w-[680px] max-w-[95vw]">{children}</div></div> : null
export const DialogHeader = ({children}:{children:any}) => <div className="p-4 border-b">{children}</div>
export const DialogTitle = ({children}:{children:any}) => <h3 className="text-lg font-semibold">{children}</h3>
export const DialogContent = ({children}:{children:any}) => <div className="p-4 space-y-3">{children}</div>
export const DialogFooter = ({children}:{children:any}) => <div className="p-4 flex justify-end gap-2 border-t">{children}</div>

export const Tabs = ({value, onValueChange, children}:{value:string, onValueChange:(v:string)=>void, children:any}) => <div>{React.Children.map(children,(ch:any)=>React.cloneElement(ch,{value, onValueChange}))}</div>
export const TabsList = ({children}:{children:any}) => <div className="flex gap-2 mt-4 flex-wrap">{children}</div>
export const TabsTrigger = ({tab, value, onValueChange, children}:{tab?:string, value?:string, onValueChange?:(v:string)=>void, children:any}) => (
  <button data-testid={`tab-${children}`} onClick={()=>onValueChange && onValueChange(tab!)} className={`px-3 py-1 rounded-full border ${value===tab?'bg-black text-white':''}`}>{children}</button>
)
export const TabsContent = ({tab, value, children}:{tab:string, value:string, children:any}) => value===tab? <div>{children}</div> : null
export const Switch = ({checked, onChange}:{checked:boolean, onChange:(v:boolean)=>void}) => (<input type="checkbox" checked={checked} onChange={(e)=>onChange(e.target.checked)} />)
